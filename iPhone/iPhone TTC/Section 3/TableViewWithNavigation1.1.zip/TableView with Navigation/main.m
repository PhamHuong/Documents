//
//  main.m
//  TableView with Navigation
//
//  Created by Jonathan Lehr on 6/21/09.
//  Copyright AboutObjects 2009. All rights reserved.
//
#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"MyAppDelegate");
    [pool release];
    return retVal;
}
